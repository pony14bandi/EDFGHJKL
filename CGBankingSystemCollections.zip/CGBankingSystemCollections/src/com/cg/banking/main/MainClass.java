package com.cg.banking.main;
import java.util.Scanner;
import com.cg.banking.beans.*;
import com.cg.banking.exceptions.*;
import com.cg.banking.services.BankingServicesImpl;
public class MainClass {


	public static void main(String[] args) throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException {
		BankingServicesImpl bankingservices=new BankingServicesImpl();
		int customerId,pinNumber,oldPinNumber,newPinNumber;
		long accountNo;
		float amount;
		int num=0;
		while(num!=11) {
			try {			
				Scanner scanner=new Scanner(System.in);		
				System.out.println("Enter "+"\n"+
						"1 : Add Customer"+"\n"+
						"2 : Open Account"+"\n"+
						"3 : Generate New Pin"+"\n"+
						"4 : Change Pin"+"\n"+
						"5 : Deposit Money"+"\n"+
						"6 : Withdraw Money"+"\n"+
						"7 : Fund Transfer"+"\n"+
						"8 : Show Balance"+"\n"+
						"9 : View All Customer Details"+"\n"+
						"10 : View Account Detaills"+"\n"+
						"11 : View AllTransaction Details");
				num=scanner.nextInt();
				switch (num) {
				case 1:	
					System.out.println("Enter Customer Details");
					System.out.println("Enter First Name");
					String firstName=scanner.next();
					System.out.println("Enter Last Name");
					String lastName=scanner.next();
					System.out.println("Enter EmailId");
					String emailId=scanner.next();
					System.out.println("Enter PanCard");
					String panCard=scanner.next();
					System.out.println("Enter LocalAddressCity");
					String localAddressCity=scanner.next();
					System.out.println("Enter LocalAddressState");
					String localAddressState=scanner.next();
					System.out.println("Enter LocalAddresspinCode");
					int localAddressPinCode=scanner.nextInt();
					System.out.println("Enter HomeAddresscity");
					String homeAddressCity=scanner.next();
					System.out.println("Enter HomeAddressState");
					String homeAddressState=scanner.next();
					System.out.println("Enter  HomeAddressPinCode");
					int  homeAddressPinCode=scanner.nextInt();
					customerId= bankingservices.acceptCustomerDetails(firstName, lastName, emailId, panCard, localAddressCity, localAddressState, localAddressPinCode, homeAddressCity, homeAddressState, homeAddressPinCode);
					System.out.println("CustomerId is" + customerId);
					break;
				case 2:
					System.out.println("Openning An Account");
					System.out.println("Enter CustomerId");
					customerId=scanner.nextInt();
					System.out.println("Enter AccountType");
					String accountType=scanner.next();
					System.out.println("Enter Initial Balance");
					float initBalance=scanner.nextFloat();
					accountNo=bankingservices.openAccount(customerId, accountType, initBalance);
					System.out.println("Account Number is" + " "+accountNo);
					break;
				case 3:
					System.out.println("Generation Of New Pin");
					System.out.println("Enter CustomerId");
					customerId=scanner.nextInt();
					System.out.println("Enter Account Number");
					accountNo=scanner.nextLong();
					int generateNewPin = bankingservices.generateNewPin(customerId, accountNo);
					System.out.println("Generated New Pin"+" "+generateNewPin);
					break;
				case 4:
					System.out.println("Changing Of Pin");
					System.out.println("Enter CustomerId");
					customerId=scanner.nextInt();
					System.out.println("Enter Account Number");
					accountNo=scanner.nextLong();
					System.out.println("Enter The Old Pin");
					generateNewPin=scanner.nextInt();
					boolean changePin = bankingservices.changeAccountPin(customerId, accountNo, oldPinNumber, newPinNumber);
					System.out.println("Generated New Pin"+" "+changePin);
					break;
				case 5:
					System.out.println("Depositing ");
					
				}
			}
		}
	}
	